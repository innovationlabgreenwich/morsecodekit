Try your best to follow the rest of the code, if you're unsure then the NASA C style can help as it's closest to the current style:

https://ntrs.nasa.gov/archive/nasa/casi.ntrs.nasa.gov/19950022400.pdf

Definetly follow PEP-8 if it's Python code.
